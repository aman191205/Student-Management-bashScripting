#!/bin/bash

# file to store student data
data_file="students.txt"

# some constants for limits and gpa stuff
max_students=20
credit_hours=3
total_credits=9
passing_cgpa=2.0

# arrays to hold student data and login users
declare -A students
declare -A users

# logins credentials
users[teacher]="T1234"
users[student]="S123"

# function to check negative numbers
is_positive_integer() {
    [[ "$1" =~ ^[0-9]+$ ]]
}

# load data from file into memory
load_data() {
    if [[ -f $data_file ]]; then
        while IFS="|" read -r roll name os db sda grade_os grade_db grade_sda gpa; do
            students[$roll]="$name|$os|$db|$sda|$grade_os|$grade_db|$grade_sda|$gpa"
        done < "$data_file"
    fi
}

# save everything back to the file
save_data() {
    > $data_file  # clear the file first
    for roll in "${!students[@]}"; do
        echo "$roll|${students[$roll]}" >> $data_file
    done
}

# login screen
login() {
    read -p "enter username: " username
    read -s -p "enter password: " password
    echo ""
    if [[ "${users[$username]}" == "$password" ]]; then
        echo "login successful!"
        if [[ "$username" == "teacher" ]]; then
            teacher_menu
        else
            student_menu
        fi
    else
        echo "invalid credentials!"
        login  # try again
    fi
}

# add a student
add_student() {
    if [[ ${#students[@]} -ge $max_students ]]; then
        echo "sorry, max students reached!"
        return
    fi
read -p "enter roll number: " roll
if ! is_positive_integer "$roll"; then
    echo "invalid roll number. must be a non-negative integer."
    return
fi
if [[ -n "${students[$roll]}" ]]; then
    echo "student already exists."
    return
fi

    read -p "enter name: " name
read -p "enter marks for os: " os
read -p "enter marks for db: " db
read -p "enter marks for sda: " sda

if ! is_positive_integer "$os" || ! is_positive_integer "$db" || ! is_positive_integer "$sda"; then
    echo "marks must be non-negative integers."
    return
fi

    # calculate grades
    grade_os=$(calculate_grade "$os")
    grade_db=$(calculate_grade "$db")
    grade_sda=$(calculate_grade "$sda")

    # calculate gpa
    gpa=$(calculate_gpa "$grade_os" "$grade_db" "$grade_sda")

    # save student record
    students[$roll]="$name|$os|$db|$sda|$grade_os|$grade_db|$grade_sda|$gpa"
    echo "student added!"
}

# delete a student
delete_student() {
    read -p "enter roll number to delete: " roll
if [[ -z "${students[$roll]}" ]]; then
    echo "student not found!"
    return
fi  
  unset students[$roll]
    echo "student deleted."
}

# update student marks
update_student() {

    read -p "enter roll number: " roll
if [[ -z "${students[$roll]}" ]]; then
    echo "student not found!"
    return
fi
read -p "enter new marks for os: " os
read -p "enter new marks for db: " db
read -p "enter new marks for sda: " sda

if ! is_positive_integer "$os" || ! is_positive_integer "$db" || ! is_positive_integer "$sda"; then
    echo "marks must be non-negative integers."
    return
fi
    IFS='|' read -r name _ <<< "${students[$roll]}"

    grade_os=$(calculate_grade "$os")
    grade_db=$(calculate_grade "$db")
    grade_sda=$(calculate_grade "$sda")
    gpa=$(calculate_gpa "$grade_os" "$grade_db" "$grade_sda")

    students[$roll]="$name|$os|$db|$sda|$grade_os|$grade_db|$grade_sda|$gpa"
    echo "record updated!"
}

# grade from marks
calculate_grade() {
    marks=$1
    if (( marks >= 90 )); then echo "A"
    elif (( marks >= 80 )); then echo "B"
    elif (( marks >= 70 )); then echo "C"
    elif (( marks >= 60 )); then echo "D"
    else echo "F"
    fi
}

# convert grade to points
grade_to_point() {
    grade=$1
    case $grade in
        A) echo "4.0" ;;
        B) echo "3.5" ;;
        C) echo "3.0" ;;
        D) echo "2.0" ;;
        F) echo "1.0" ;;
    esac
}

# gpa calculator
calculate_gpa() {
    g1=$(grade_to_point $1)
    g2=$(grade_to_point $2)
    g3=$(grade_to_point $3)

    total=$(echo "scale=2; ($g1 + $g2 + $g3) * $credit_hours / $total_credits" | bc)
    echo "$total"
}

# view student by roll
view_student() {
    read -p "enter roll number: " roll
if ! is_positive_integer "$roll"; then
    echo "invalid roll number."
    return
fi
  
  if [[ -z "${students[$roll]}" ]]; then
        echo "no student found."
        return
    fi
    IFS='|' read -r name os db sda g_os g_db g_sda gpa <<< "${students[$roll]}"
    echo "name: $name"
    echo "os: $os, grade: $g_os"
    echo "db: $db, grade: $g_db"
    echo "sda: $sda, grade: $g_sda"
    echo "gpa: $gpa"
}

# just show gpa
view_cgpa() {
    read -p "enter roll number: " roll
if ! is_positive_integer "$roll"; then
    echo "invalid roll number."
    return
fi
    if [[ -z "${students[$roll]}" ]]; then
        echo "no student found."
        return
    fi
    IFS='|' read -r _ _ _ _ _ _ _ gpa <<< "${students[$roll]}"
    echo "gpa: $gpa"
}

# display all students
display_students() {
    echo "roll | name | os | db | sda | grade os | grade db | grade sda | gpa"
    echo "--------------------------------------------------------------------------"
    for roll in "${!students[@]}"; do
        IFS='|' read -r name os db sda g_os g_db g_sda gpa <<< "${students[$roll]}"
        echo "$roll | $name | $os | $db | $sda | $g_os | $g_db | $g_sda | $gpa"
    done | column -t -s '|'
}

# sort students based on gpa
sort_students() {
    read -p "sort by gpa (a for ascending, d for descending): " order
if [[ "$order" != "a" && "$order" != "A" && "$order" != "d" && "$order" != "D" ]]; then
    echo "invalid input."
    return
fi
  
  if [[ "$order" == "a" || "$order" == "A" ]]; then
        sort_flag="-k9,9"
    else
        sort_flag="-k9,9 -r"
    fi
    echo "roll | name | os | db | sda | grade os | grade db | grade sda | gpa"
    echo "--------------------------------------------------------------------------"
    for roll in "${!students[@]}"; do
        echo "$roll|${students[$roll]}"
    done | sort -t '|' $sort_flag | column -t -s '|'
}

# show who passed and who didn’t
list_passed_failed() {
    echo "passed students:"
    for roll in "${!students[@]}"; do
        IFS='|' read -r name os db sda g_os g_db g_sda gpa <<< "${students[$roll]}"
        if (( $(echo "$gpa >= $passing_cgpa" | bc -l) )); then
            echo "$roll | $name | gpa: $gpa"
        fi
    done | column -t -s '|'

    echo "failed students:"
    for roll in "${!students[@]}"; do
        IFS='|' read -r name os db sda g_os g_db g_sda gpa <<< "${students[$roll]}"
        if (( $(echo "$gpa < $passing_cgpa" | bc -l) )); then
            echo "$roll | $name | gpa: $gpa"
        fi
    done | column -t -s '|'
}

# menu for teacher login
teacher_menu() {
    while true; do
        echo "===== teacher menu ====="
        echo "1. add student"
        echo "2. delete student"
        echo "3. update student marks"
        echo "4. view student details"
        echo "5. display all students"
        echo "6. sort students by gpa"
        echo "7. list passed & failed"
        echo "8. save data"
        echo "9. load data"
        echo "0. logout"
        read -p "choose an option: " choice
        case $choice in
            1) add_student ;;
            2) delete_student ;;
            3) update_student ;;
            4) view_student ;;
            5) display_students ;;
            6) sort_students ;;
            7) list_passed_failed ;;
            8) save_data ;;
            9) load_data ;;
            0) echo "logging out..."; return ;;
            *) echo "invalid option" ;;
        esac
    done
}

# menu for student login
student_menu() {
    while true; do
        echo "===== student menu ====="
        echo "1. view grades"
        echo "2. view gpa"
        echo "0. logout"
        read -p "choose an option: " choice
        case $choice in
            1) view_student ;;
            2) view_cgpa ;;
            0) echo "logging out..."; return ;;
            *) echo "invalid option" ;;
        esac
    done
}

# load existing data and start login
load_data
login
